# WPFChat
A WPF chat application using TCP sockets.

Theme in the application is MahApps: http://mahapps.com/
</br>
Icons in the application are from: https://www.iconfinder.com

# Images
![Server Application](https://imgur.com/1L7IrMW.png)
</br>
![Client Application](https://imgur.com/qkZPu3I.png)

